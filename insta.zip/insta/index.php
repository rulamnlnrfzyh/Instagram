<?php
session_start();
if(!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=logindulueuyy");
}
include "koneksi.php";
$sql ="SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>AE</title>
    <link rel="icon" href="img/logoae.png">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
body {

  background-image : url(/insta/img/bg.jpg);
}
.zoom {
  
  transition: transform .2s; /* Animation */
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.3); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
</head>
<body class="">
<nav class="navbar sticky-top navbar-expand-lg" style="background-color: #050505;">
  <div class="container-fluid">
  <img src="img/logoae.png" width="45" height="45" class="mr-3">
    <a class="navbar-brand"><font face="Times New Roman" style="color: #f5f5f5;">ALTER EGO</font></a>
    <div align="right">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-square-plus"></i>
</button>
    <a href="logout.php" class="btn btn-danger "><i class="fa-solid fa-arrow-right-from-bracket" style="color: #fffff;"></i></a>
    </div>
  </div>
  </div>
</nav>

<div>
<?php while($post = mysqli_fetch_assoc($query)) { ?>
    <div align="center" class="container" >
    <br><div class="card mt-3" style="width: 18rem; background-color: #2e2e2e;">

    <div class="card-header" align="left">
      <img src="img/logoae.png" width="25">
      <strong style="color: #f5f5f5"><?=$_SESSION['login']?></strong>
    <div class="zoom">
    <img class="card-img-top" src="images/<?= $post['foto'] ?>" height="230" width="50" alt="Card image cap">
    </div>
</div>
   

    <div class="card-body" align="left">
    <h5 class="card-text" style="color: #f5f5f5;"><?= $post['caption'] ?></h5>
    <p class="card-text" style="color: #f5f5f5;"><?= $post['lokasi'] ?></p>
    </div>


    <div align="right">
    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$post['no']?>"><i class="fa-solid fa-pen-to-square"></i></button>
    <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('Anda Yakin Untuk Menghapus?')" class = "btn btn-danger btn-sm"><i class="fa-solid fa-trash-can" style="color: #000000;"></i></a>
    </div>
 
</div>
        </div>
        <div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #000000;">
        <h2 class="modal-title fs-5 text-white" id="staticBackdropLabel" >Edit Player</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <div class="container" align="left">
        <label for="">Images</label>
        

        <div align="left">
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="file" name="foto" class="form-control" value="<?= $post['foto'] ?>" ><br>
        </div>

       
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
        

       
        <label for="">Location</label>
        <input type="text" name="lokasi" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        
        <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        <input type="submit" value="Update" name="update" class="btn btn-primary">
</div>
    </form>
</div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
    </div>
    </div>
    </div>
    </div>
  <?php } ?>
    </div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #000000;">
        <h2 class="modal-title fs-5 text-white" id="exampleModalLabel">Tambah Player</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="">Images</label>
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="file" name="foto" class="form-control" ><br>
       
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control"  autocomplete="off"><br>
        <label for="">Location</label>
        <input type="text" name="lokasi" class="form-control"  autocomplete="off"><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        <input type="submit" class="btn btn-primary" name="simpan" value="Simpan"> 
      </div>
    </div>
</form>
  </div>
</div>
</body>
</html>
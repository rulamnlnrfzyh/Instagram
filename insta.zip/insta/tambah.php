<?php
session_start();
if(!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=logindulueuyy");
}
include "koneksi.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AE</title>
    <link rel="icon" href="img/logoae.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <br><br>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="">Images</label>
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="file" name="foto" class="form-control" ><br>
       
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control"  autocomplete="off"><br>
        <label for="">Location</label>
        <input type="text" name="lokasi" class="form-control"  autocomplete="off"><br>

        
        <input type="submit" value="Simpan" name="simpan" class="btn btn-primary">
    </form>
    </div>
</body>
</html>

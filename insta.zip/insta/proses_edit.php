<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $foto_lama = $_POST['foto_lama'];
    $foto_baru = $_FILES['foto']['name'];

   
    if( $_FILES['foto']['error'] === 4 ) {
		$foto = $foto_lama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    

        while($post = mysqli_fetch_assoc($query)) {
            $foto = $post['foto'];
            unlink('images/' . $foto);
        }

      
		$foto = upload();
	}
    
    $sql2 = "UPDATE post SET caption = '$caption', foto = '$foto', lokasi = '$lokasi' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        echo "<script>
        alert('Berhasil Mengedit')
        window.location='index.php';
        </script>";
    } else {
        echo "<script>
        alert('Gagal Mengedit')
        window.location='index.php';
        </script>";
    }
    
}
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AE</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/logoae.png">
    <style>
body {
        background-image : url(/insta/img/bg.jpg);
}
    </style>
</head>
<body class="" style="background-color: #050505;">
    <div class="container">
    <form action="proses_login.php" method="post">
        <div align="center">
            <img src="img/logoae.png" width="90" height="90" alt="">
        </div><br>

        <label for="username" style="color: #050505;" >Username</label>
        <input type="text" id="username" name="username" autocomplete="off" required placeholder=" Enter Username">

        <label for="password" style="color: #050505;">Password</label>
        <input type="password" id="password" name="password" required placeholder="Enter Password">

        <button input type="submit" value="Sign In">Login</button>
    </form>
</div>
</body>
</html>